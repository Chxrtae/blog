<h1><?php echo $dados['titulo'];    ?></h1>
<p> <?php echo $dados['descricao']; ?></p>